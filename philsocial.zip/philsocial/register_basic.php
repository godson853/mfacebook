
<?php
//set up mysql connection
mysql_connect("localhost", "root", "") or die(mysql_error());
//select database
mysql_select_db("philsocialdb") or die(mysql_error());

$f_name = $_POST['fName'];
$l_name = $_POST['lName'];
$email = $_POST['email'];
$password = sha1($_POST['password']);
$month	  = $_POST['month']; 
$month    = $month + 1;
$day	  = $_POST['day'];
$yr	      = $_POST['yr'];
$bday     = $yr . '-' . $month . '-' .  $day;
$gender   = $_POST['gender'];

$query = "INSERT INTO `user_info` (`fName`, `lName`, `email`, `pword`, `gender`, `bday`) 
VALUES ('{$f_name}', '{$l_name}', '{$email}', '{$password}','{$gender}','{$bday}')";
					
if (mysql_query($query)) {
    
    echo "<script type=\"text/javascript\">
                alert(\"New member added successfully.\");
                window.location = \"index.php\"
            </script>";
    
} else{
    die("Failed: " . mysql_error());
}
?>