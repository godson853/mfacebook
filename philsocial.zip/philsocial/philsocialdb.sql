-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 21, 2014 at 06:46 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `philsocialdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `basic_info`
--

CREATE TABLE IF NOT EXISTS `basic_info` (
  `basicinfo_id` int(11) NOT NULL AUTO_INCREMENT,
  `networks` varchar(255) NOT NULL DEFAULT 'None',
  `interested_in` varchar(30) NOT NULL DEFAULT 'Women',
  `rel_stats` varchar(30) NOT NULL DEFAULT 'Single',
  `language` varchar(255) NOT NULL DEFAULT 'None',
  `religion` varchar(255) NOT NULL DEFAULT 'None',
  `rel_desc` text NOT NULL,
  `political_view` varchar(255) NOT NULL,
  `pol_desc` text NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`basicinfo_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `basic_info`
--

INSERT INTO `basic_info` (`basicinfo_id`, `networks`, `interested_in`, `rel_stats`, `language`, `religion`, `rel_desc`, `political_view`, `pol_desc`, `member_id`) VALUES
(7, 'Facebook', 'Men', 'Widowed', 'Filipino', 'Catholic', '	asdas															', 'dsdfsd', '	sadsadsd															', 25),
(6, 'Google', 'Women', 'In an open Relationship', 'English', 'Catholic', 'No comment																', 'I dont like politics', 'No Comment																', 24),
(8, '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>217</b><br />', 'Women', 'Sinlge', 'English, Tagalog, Hiligaynon', 'Baptist', '												\r\n																', '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>382</b><br />', '																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>397</b><br />\r\n																', 31),
(9, '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>217</b><br />', 'Men', 'Sinlge', 'English.Tagalog, Hiligaynon', 'Roman Catholic', '																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>368</b><br />\r\n																', '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>382</b><br />', '																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>397</b><br />\r\n																', 33),
(10, '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>217</b><br />', 'Women', 'Sinlge', 'English, Tagalog, Ilonggo, Hiligaynon', 'Roman Catholic', '																																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>368</b><br />\r\n																																', '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>382</b><br />', '																																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>397</b><br />\r\n																																', 29),
(11, '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>217</b><br />', 'Men', 'Maried', 'Hiligaynon, Tagalog,Japanese,korean', 'Roman Catholic', '', '<br /><b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>382</b><br />', '																<br />\r\n<b>Notice</b>:  Trying to get property of non-object in <b>C:xampphtdocsphilsocialinfo.php</b> on line <b>397</b><br />\r\n																', 32),
(12, 'EJB Tech', 'Women', 'Maried', 'English', 'Roman Catholic', '													', 'Boycot', '																	None																', 61),
(13, 'networks', 'Women', 'Sinlge', 'english', 'catholic', '																																	', '', '																	None																', 64);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `to` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment_id`, `content`, `author`, `to`, `created`) VALUES
(52, 61, 'Welcome philsocial dot com', 'jason batuto', 61, '2014-01-16 04:15:57'),
(20, 17, 'sdsdsf', 'testfname testLanmee', 17, '2013-11-26 02:23:38'),
(8, 17, 'Another user test comments\r\n', '17', 17, '2013-11-25 05:59:15'),
(23, 18, 'Its complicated... :) ', 'Joenin Selvido', 18, '2013-11-26 09:55:49'),
(14, 17, 'Another \r\nTesting \r\nComment!', 'testfname testLanmee', 17, '2013-11-25 07:46:02'),
(15, 17, 'Test Error comment!', 'testfname testLanmee', 17, '2013-11-25 07:46:25'),
(16, 17, 'New photo Uploaded!.', 'testfname testLanmee', 17, '2013-11-25 09:55:37'),
(24, 15, 'hello....', 'janno palacios', 15, '2013-11-26 11:53:55'),
(50, 33, ':))', 'Lasthen Rosales', 33, '2014-01-07 01:14:16'),
(26, 20, 'Amazing ', 'CHRISTIAN PALOMO', 20, '2013-11-27 12:12:17'),
(27, 21, 'Hello Im rea.', 'Rea Cabiten', 21, '2013-11-28 06:52:05'),
(51, 41, 'Good morning everyone', 'Elsie Elijan', 41, '2014-01-07 01:15:05'),
(49, 31, '#AI', 'Ana Mae Puyogao', 31, '2014-01-07 01:12:55'),
(30, 22, 'Exited nku mag program sa AI nga subject!.', 'Cherry anne Bobon', 22, '2013-12-02 10:11:24'),
(44, 12, 'sdfsfsfsdf', 'Joken Villanueva', 12, '2013-12-11 09:23:39'),
(48, 24, 'asdsad\r\n', 'Joken Villanueva', 24, '2013-12-16 13:56:47'),
(40, 12, 'what on your mind?.', 'Joken Villanueva', 12, '2013-12-11 09:23:03'),
(42, 12, 'sdfsdfsdf', 'Joken Villanueva', 12, '2013-12-11 09:23:31'),
(43, 12, 'sdsdfsdfsdf', 'Joken Villanueva', 12, '2013-12-11 09:23:34');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `friend_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `friend_status` varchar(30) NOT NULL DEFAULT 'pending',
  `friend_with` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`friend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `friends`
--


-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `member_id` int(11) NOT NULL,
  `pri` varchar(12) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `filename`, `type`, `size`, `caption`, `member_id`, `pri`) VALUES
(19, '02.jpg', 'image/jpeg', 219880, '', 13, ''),
(20, '487940_605114892866654_256031780_n.jpg', 'image/jpeg', 75454, '', 14, ''),
(21, '564090_641102355934574_1372552796_n.jpg', 'image/jpeg', 57551, '', 12, 'no'),
(22, '403366_247819538629389_985850300_n.jpg', 'image/jpeg', 83045, '', 15, ''),
(23, '403366_247819538629389_985850300_n.jpg', 'image/jpeg', 83045, '', 10, ''),
(24, 'Chrysanthemum.jpg', 'image/jpeg', 879394, '', 16, ''),
(25, 'Koala.jpg', 'image/jpeg', 780831, 'gfgfgfg', 0, ''),
(26, 'Koala.jpg', 'image/jpeg', 780831, 'koala', 0, ''),
(27, 'Penguins.jpg', 'image/jpeg', 777835, '', 17, 'no'),
(28, 'alarm scheduler.png', 'image/png', 28194, '', 18, ''),
(29, 'Penguins.jpg', 'image/jpeg', 777835, '', 19, ''),
(30, 'backgroundimg.jpg', 'image/jpeg', 205908, '', 20, ''),
(31, 'Photo.jpg', 'image/jpeg', 1583, '', 21, ''),
(33, '02.jpg', 'image/jpeg', 219880, '', 12, 'no'),
(37, '02.jpg', 'image/jpeg', 219880, '', 12, 'no'),
(38, '02.jpg', 'image/jpeg', 219880, '', 12, 'no'),
(40, '02.jpg', 'image/jpeg', 219880, '', 12, 'no'),
(41, 'Koala.jpg', 'image/jpeg', 780831, '', 12, 'no'),
(42, 'Penguins.jpg', 'image/jpeg', 777835, '', 17, 'yes'),
(43, 'Jellyfish.jpg', 'image/jpeg', 775702, '', 22, 'yes'),
(44, 'harly1.jpg', 'image/jpeg', 53403, '', 12, 'no'),
(45, 'harley.jpg', 'image/jpeg', 46808, '', 12, 'no'),
(46, 'Penguins.jpg', 'image/jpeg', 777835, '', 12, 'no'),
(47, 'backgroundimg.jpg', 'image/jpeg', 205908, '', 12, 'yes'),
(48, 'images (13).jpg', 'image/jpeg', 5304, '', 24, 'no'),
(49, '1144059_vb.jpg', 'image/jpeg', 9622, '', 31, 'yes'),
(50, '1134009_vb.jpg', 'image/jpeg', 6513, '', 33, 'yes'),
(51, 'scarlet.jpg', 'image/jpeg', 122586, '', 41, 'yes'),
(52, 'Chrysanthemum.jpg', 'image/jpeg', 879394, '', 24, 'no'),
(53, 'Hydrangeas.jpg', 'image/jpeg', 595284, '', 24, 'no'),
(54, 'Penguins.jpg', 'image/jpeg', 777835, '', 24, 'no'),
(55, 'Koala.jpg', 'image/jpeg', 780831, '', 24, 'no'),
(56, 'download (1).jpg', 'image/jpeg', 7822, '', 24, 'no'),
(57, 'backgroundimg.jpg', 'image/jpeg', 205908, '', 24, 'yes'),
(58, 'PC260110.JPG', 'image/jpeg', 895529, '', 61, 'yes'),
(59, 'Snapshot_20130222_6.JPG', 'image/jpeg', 53746, '', 64, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `subcomment`
--

CREATE TABLE IF NOT EXISTS `subcomment` (
  `subc_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) NOT NULL,
  `subauthor` varchar(255) NOT NULL,
  `subcontent` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`subc_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `subcomment`
--

INSERT INTO `subcomment` (`subc_id`, `comment_id`, `subauthor`, `subcontent`, `created`) VALUES
(2, 12, 'Joken Villanueva', 'Test Subcomment attempt 1.', '2013-11-26 08:53:02'),
(5, 18, 'Joken Villanueva', 'sdsdssdsdssd', '2013-11-26 08:59:37'),
(6, 17, 'Joken Villanueva', 'Tsdf', '2013-11-26 08:59:47'),
(7, 21, 'Joken Villanueva', 'Test Attempt sub comment j=ky dw medyu ok na.', '2013-11-26 09:15:03'),
(8, 21, 'Joken Villanueva', 'Test Attempt sub comment j=ky dw medyu ok na. No 2.', '2013-11-26 09:21:26'),
(9, 22, 'Joken Villanueva', 'sub comment', '2013-11-26 09:43:26'),
(13, 22, 'Joken Villanueva', 'sub comment 2', '2013-11-27 04:49:47'),
(11, 23, 'Joenin Selvido', 'sir', '2013-11-26 09:55:57'),
(12, 24, 'janno palacios', 'hellooooowww...s', '2013-11-26 11:54:15'),
(14, 25, 'Joken Villanueva', 'Naka red tshirt!', '2013-11-27 06:47:46'),
(15, 26, 'CHRISTIAN PALOMO', 'Awsome ang amazing ;;;', '2013-11-27 12:12:40'),
(16, 27, 'Rea Cabiten', 'T sorry lg?', '2013-11-28 06:52:19'),
(18, 28, 'Joken Villanueva', 'jj', '2013-11-29 11:54:23'),
(19, 29, 'Joken Villanueva', 'wla basagan nang trip!', '2013-12-02 10:08:09'),
(20, 30, 'Cherry anne Bobon', 'Lantawon ta b!', '2013-12-02 10:11:45'),
(25, 36, 'Joken Villanueva', 'hahaha', '2013-12-11 09:15:42'),
(26, 37, 'Joken Villanueva', 'sad', '2013-12-11 09:16:47'),
(27, 39, 'Joken Villanueva', 'basa pa', '2013-12-11 09:22:49'),
(24, 34, 'Joken Villanueva', 'd iuashduihsasd iuasdiuauhsd uhd uhsd sduhsd usdhsd ushds dsud iusdhh  iuhsd shdiu asdiuashd iusadh saiud adiuhsaid u', '2013-12-11 07:14:13'),
(34, 48, 'Joken Villanueva', 'dsfjsdf', '2013-12-16 13:57:13'),
(29, 44, 'Joken Villanueva', 'sdfsdfsdf', '2013-12-11 09:23:47'),
(30, 43, 'Joken Villanueva', 'dfgdfgg', '2013-12-11 09:23:50'),
(31, 43, 'Joken Villanueva', 'f', '2013-12-11 09:23:53'),
(35, 52, 'jason batuto', 'asa naman ang iban.', '2014-01-17 03:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `fName` varchar(30) NOT NULL,
  `lName` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pword` varchar(60) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `bday` date NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`member_id`, `fName`, `lName`, `email`, `pword`, `gender`, `bday`) VALUES
(24, 'Joken', 'Villanueva', 'joken@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Male', '2010-01-31'),
(25, 'Allan', 'Gregorio', 'allan@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Female', '1996-03-29'),
(27, 'Gina', 'bulgado', 'carlghin_52@yahoo.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Female', '1992-06-28'),
(28, 'Arhil Jun', 'Macario', 'elehra_jun_09@yahoo.com', 'f692a4145a9d124d82226050913431fe8456fe08', 'Male', '1993-06-12'),
(29, 'Rhea May', 'Cabiten', 'rean7901@gmail.com', 'ca9621fa57b01e9382e6928d8a695c4c9eb6da2f', 'Male', '2010-01-31'),
(30, 'Jojean', 'CastaÃ±o', 'Jojean_c@yahoo.com', 'af7cb1b88d799b23600acabce086857327300c2c', 'Female', '1994-09-27'),
(31, 'Ana Mae', 'Puyogao', 'puyogaoanamae@yahoo.com', 'f09a13f6be1e034646e3a3f033e514f38013211e', 'Male', '2010-01-31'),
(32, 'Ma. Lavinia', 'Daulong', 'corsin90@yahoo.com', '6db2e3247dd5ad64abfa2c5da885b51c90b93bc1', 'Female', '1994-06-09'),
(33, 'Lasthen', 'Rosales', 'rlasthen@yahoo.com', '1473d61059a725bd336a5b46a6949321b7d0582c', 'Female', '1992-11-18'),
(34, 'Diwannie', 'Arillo', 'dj_arillo@yahoo.com', 'e425a2f93ac71d0b145c29f6ad1f52455864e9af', 'Female', '1992-10-12'),
(35, 'Steve', 'Flores', 'skevinz_23@ymail.com', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 'Male', '1993-01-02'),
(36, 'Benigno', 'Cortez', 'deadlyjay_23@yahoo.com', '77e697477386aa6337d7eba2b3010ce6641a1270', 'Female', '1992-02-03'),
(37, 'Jerom', 'Melanio', 'melaniojerom@yahoo.com', 'f2aaa980bdccb5ec06c14311646b7d61e59a1d3c', 'Male', '1992-10-12'),
(38, 'Carjei', 'Gamala', 'kai_luv@yahoo.com', '69872a6e81701a0751b5cb96e02f519f049c4b70', 'Male', '1993-04-28'),
(39, 'Jenny', 'Deanon', 'jenny_16@yahoo.com', '6a3f4389a53c889b623e67f385f28ab8e84e5029', 'Female', '1992-12-16'),
(40, 'Gergen Mae', 'Geria', 'geriaergenmage@yahoo.com', 'a38947fa68173715fe75f31564137adb150c67b1', 'Female', '1994-05-18'),
(41, 'Elsie', 'Elijan', 'cute_elz20@yahoo.com', '69402028d8c9cad929990fe1bea4e15c3dbc033b', 'Female', '1989-10-08'),
(42, 'Liezl', 'Silleva', 'lieztryx_16@yahoo.com', '8cb2237d0679ca88db6464eac60da96345513964', 'Female', '1994-05-20'),
(43, 'roselyn', 'espadero', 'roselynt.espadero@yahoo.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Female', '1989-02-11'),
(44, 'Lenwil', 'Platero', 'lenwil@rocketmail.com', '6721af5e74dc3ed8b7986120f99015be3253394a', 'Male', '1991-02-17'),
(45, 'carmina', 'mangao', 'carmina_dawn@yahoo.com', '703e57ceeb88f08875ccf3d87e59e13347d22ace', 'Female', '1993-04-30'),
(46, 'JohnAnthony', 'salopisa', 'jsalopisa@yahoo.com', '57b2ad99044d337197c0c39fd3823568ff81e48a', 'Male', '1989-09-20'),
(47, 'Joepy', 'Pedrigon', 'jopz@yahoo.com', 'fdb313dfd7c873830af2572e3eeb5a678f7303cb', 'Female', '1992-05-02'),
(48, 'ivan', 'oguilla', 'ivan.earl@ymail.com', '6d199aca996a9a8bff542e2bc10e3f0edc62cd07', 'Male', '1993-07-25'),
(49, 'jose', 'jong', 'crushed_RFG@yahoo.com', '68385704da937ed90ecc61d6fe665d3291a5338a', 'Male', '1990-10-17'),
(50, 'Win-win', 'Moncatar', 'iamsuperwin2@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Female', '1992-11-29'),
(51, 'Cherry Ann', 'Bobon', 'cherryblossoms093@yahoo.com', '64d0955f3edd3de6a601d63f595cb5939f833be3', 'Female', '1993-02-11'),
(52, 'Van Dyck', 'Sanchez', 'dyckvan@gmail.com', '769756305455a7e7e6cce8650cb67ca8f6a53ed5', 'Male', '1990-08-09'),
(53, 'Humpherdinck ', 'dela Cruz', 'humpz_12@yahoo.com', '4a74986a250d9915cd59098d164e4fe0760bf170', 'Male', '1989-02-17'),
(54, 'JAYL', 'APLAON', 'jelay@yahoo.com', 'e714d0090070419bd248c33b570aae5193927268', 'Female', '1992-09-21'),
(55, 'am', 'casio', 'tomito@yahoo.com', '21cbb5a6f74358e9aa5a08e425bb6b2ee31e5b24', 'Female', '1992-04-11'),
(56, 'kim', 'macaya', 'mikrenar_ayacam@yahoo.com', 'a9eab58f038bdeaec06f50470fb0bd6b93148941', 'Female', '1993-04-01'),
(57, 'Angelie', 'Calalas', 'janjie29@gmail.com', '6d819ff4f8581a404c0c1a232fb4c738f9c310e6', 'Female', '1991-11-06'),
(58, 'maricon', 'de leon', 'deleonoce@yahoo.com', '05b98606c4c32bf36fe64fe203b98d10b2818dab', 'Female', '1993-06-18'),
(59, 'Maryrose', 'Mission', 'MR_12345@yahoo.com', 'e59abed352187d91ebc12f44c8329e29b4656254', 'Female', '1993-10-09'),
(60, 'a', 'Amparado', 'jayanne27dubai@yahoo.com', '86f7e437faa5a7fce15d1ddcb9eaeaea377667b8', 'Female', '1994-02-18'),
(61, 'jason', 'batuto', 'ejbatuto@hotmail.com', 'a2f78862735df60879302363d85a5e76faa2fcaa', 'Male', '1992-12-26'),
(62, 'testfname', 'ter', 'test@y.c', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Male', '1994-01-13'),
(63, 'rex', 'delos santos', 'rex_2071@yahoo.com', '821d647e68eda09ece6447b37a3f5ffcbcf5823f', 'Male', '1990-05-20'),
(64, 'raymond', 'dajeno', 'raymond@yahoo.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Male', '1990-05-20');
