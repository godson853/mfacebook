window.onload = initForms;
function initForms(){


}
