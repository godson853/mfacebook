<?php	
require_once("includes/initialize.php");	
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="">

    <title>Philsocial</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="jumbotron.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="../../assets/js/html5shiv.js"></script>
      <script src="../../assets/js/respond.min.js"></script>
    <![endif]-->
	<?php 
	    //login confirmation
		confirm_logged_in();
	?> 
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="home.php"><B>Philsocial</B></a>
        </div>
        <form class="navbar-form navbar-left">
            <div class="form-group">
			<div class="rows">
              <input type="text" placeholder="Email" class="form-control" size="40">
            </div>
           </div>
          </form>
		<div class="navbar-collapse collapse">
         
          <form class="navbar-form navbar-right">
            <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
           <li class="dropdown">
			
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">
			<?php 
			//retrieve session variable
			echo $_SESSION['fName'];?> 
				<b class="caret"></b>
			</a>
             
			 <ul class="dropdown-menu">
                <li><a href="#">My Profile</a></li>
                <li><a href="#">Edit profile</a></li>
                <li><a href="#">Edit profile Picture</a></li>
				<li><a href="#">Customize profile</a></li>
				<li><a href="#">Edit Work and Education</a></li>
               
              </ul>
            </li>
			<li class="dropdown">

			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Account<b class="caret"></b></a>
             
			 <ul class="dropdown-menu">
                <li><a href="#">Account Settings</a></li>
                <li><a href="#">Privacy Settings</a></li>
                <li><a href="#">Manage Social Accounts</a></li>
				<li><a href="#">Manage Credits</a></li>
				<li><a href="logout.php">Logout</a></li>
               
              </ul>
            </li>
          </ul>
		</form>
        </div><!--/.navbar-collapse -->
      </div>
    </div>
<div class="container">
		<div class="well">
	
			<div class="row">
				<div class="col-xs-6 col-md-2">
						<a data-target="#myModal" data-toggle="modal" href="" title=
						"Click here to Change Image.">
				<?php
				
				$mydb->setQuery("SELECT * FROM photos WHERE `member_id`='{$_SESSION['member_id']}' and pri='yes'");
				$cur = $mydb->loadResultList();
				if ($mydb->affected_rows()== 0){
					echo '<img src="./uploads/p.jpg" class="img-thumbnail" width="200px" height="100px" />';	
				
				} 
				foreach($cur as $object){
				   
						echo '<img src="./uploads/'. $object->filename.'" class="img-thumbnail" width="200px" height="100px" />';
					
					}	
				?> 
					</a>	
					
				<!-- Modal -->
					<div class="modal fade" id="myModal" tabindex="-1">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header">
									<button class="close" data-dismiss="modal" type=
									"button">×</button>

									<h4 class="modal-title" id="myModalLabel">Choose Your best
									picture for your Profile.</h4>
								</div>

								<form action="save_photo.php" enctype="multipart/form-data" method=
								"post">
									<div class="modal-body">
										<div class="form-group">
											<div class="rows">
												<div class="col-md-12">
													<div class="rows">
														<div class="col-md-8">
															<input name="MAX_FILE_SIZE" type=
															"hidden" value="1000000"> <input id=
															"upload_file" name="upload_file" type=
															"file">
														</div>

														<div class="col-md-4"></div>
													</div>
												</div>
											</div>
										</div>
									</div>

									<div class="modal-footer">
										<button class="btn btn-default" data-dismiss="modal" type=
										"button">Close</button> <button class="btn btn-primary"
										name="savephoto" type="submit">Save Photo</button>
									</div>
								</form>
							</div><!-- /.modal-content -->
						</div><!-- /.modal-dialog -->
					</div><!-- /.modal -->
				</div>

				<div class="col-xs-12 col-sm-6 col-md-8">
					<div class="page-header">
						<h3><?php echo $_SESSION['fName']. ' '. $_SESSION['lName'];?></h3>
					</div>

					<ul class="nav nav-tabs">
						<li class="active">
							<a href="#">Wall</a>
						</li>

						<li>
							<a href="info.php">Info</a>
						</li>

						<li>
							<a href="message.php">Messages</a>
						</li>
					</ul>
				<div class="well">
				<div class="row">
				
					<div class="panel-group" id="accordion">
					  <div class="panel panel-primary">
						<div class="panel-heading">
						  <h5 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" title="What's on your mind?">
							 Update Status
							</a>
							</h5>
						</div>
						
						<form action="save_post.php" method="POST">
						<div id="collapseOne" class="panel-collapse collapse">
						  <div class="panel-body">
							<input type="hidden" name="comment_id" value="<?php echo $_SESSION['member_id']; ?>">
							<input type="hidden" name="author" value="<?php echo $_SESSION['fName']. ' '. $_SESSION['lName']; ?>">
							<input type="hidden" name="to" value="<?php echo $_SESSION['member_id']; ?>">
							<textarea class="form-control" name="content" placeholder="What's on your mind?"></textarea>
								
						</div>
						<div class="panel-footer" align="right">
							<button class="btn btn-primary btn-sm" type="submit" name="share">Share</button>
						</div>
						</div>
						</form>
					  </div>
					</div>	
				<div class="col-lg-12">
					<?php
					function date_toText($datetime=""){
							$nicetime = strtotime($datetime);
							return strftime("%B %d, %Y at %I:%M %p", $nicetime);	
						
						}
					
				global $mydb;	
					$mydb->setQuery("SELECT * from comments where comment_id=".$_SESSION['member_id']." ORDER BY created DESC");
					$cur = $mydb->loadResultList();
				
					foreach ($cur as $comm){
					$mydb->setQuery("SELECT * FROM photos WHERE `member_id`='{$_SESSION['member_id']}' and pri='yes'");
						$propic = $mydb->loadResultList();
						
						if ($mydb->affected_rows()== 0){
							echo '<div class="col-lg-1"><img src="./uploads/p.jpg" class="img-object" width="50px" height=60px" /></div>';	
						
						} 
						foreach ($propic as $obj){
							
							echo '<div class="col-lg-1"><img src="./uploads/'. $obj->filename.'" class="img-object" width="50px" height="60px" /></div>';
							
						}	
								
						echo '<div class="col-lg-10">';
						echo '<a href="home.php?id='.$_SESSION['member_id'].'">'.$comm->author.'</a>';		
						echo '</div>';
						
						echo '<div class="row">';
							echo '<div class="col-lg-10">';
								echo '<p>'.$comm->content. '<br/><a>comment </a>'.$comm->created.'</p>';
						
						echo '<div class="row">';
							echo '<div class="col-lg-12">';

						/* this area is for listing of sub-comment*/
				/* 		$mydb->setQuery("SELECT * FROM  `subcomment` WHERE `comment_id` = ".$comm->id );
						$sub = $mydb->loadResultList();
						foreach ($sub as $subcomm){
								
										
										$mydb->setQuery("SELECT * FROM photos WHERE `member_id`='{$_SESSION['member_id']}' and pri='yes'");
												$propic = $mydb->loadResultList();
												if ($mydb->affected_rows()== 0){
													echo '<img src="./uploads/p.jpg" class="img-object" width="30px" height=40px" />';	
												
												} 
												foreach ($propic as $obj){
													
													echo '<img src="./uploads/'. $obj->filename.'" class="img-object" width="30px" height="40px" />';
												}	
												
										echo '<p><a href="home.php?id='.$_SESSION['member_id'].'">
												'.$comm->author.'</a>'.$subcomm->subcontent .'</p><div style="font-size: 0.9em"><p>'.date_toText($subcomm->created).'</p> </div>';
															
								
												
						}  */
						
						
						//4GH2FTUOP
						//		echo '<tr><td>df</td></tr>';			
							//This area is for creating a new comment
							
									
									echo '<form action="save_subcomm.php" method="post">';
										echo '<input name="commentid" type="hidden" value="'. $comm->id .'">';
										echo '<input name="subauthor" type="hidden" value="'. $_SESSION['fName']. ' '. $_SESSION['lName'] .'">';
										
										$mydb->setQuery("SELECT * FROM photos WHERE `member_id`='{$_SESSION['member_id']}' and pri='yes'");
										$propic = $mydb->loadResultList();
										if ($mydb->affected_rows()== 0){
											echo '<img src="./uploads/p.jpg" class="img-object" width="30px" height=30px" />';	
										
										} 
										foreach ($propic as $obj){
											echo '<img src="./uploads/'. $obj->filename.'" class="img-object" width="30px" height="30px" />';
										
										}	
										
									echo '<td><input name="subcontent" type="text" style="width: 370px;" class="form-control" placeholder="Write a comment...">';
									echo '</form>';
							
							
								echo '</div>';//end of col 12
							echo '</div>';//end of col-lg-10

						echo '</div>';
					
					}
					?>
					
					</div>
				
				</div>
			</div>
		</div>
	</div>
     
  </body>
</html>
 
      <hr>
    
    </div> <!-- /container -->
	<footer>
        <p align="center">&copy; Philsocial 2013</p>
    </footer>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
     <script src="js/tooltip.js"></script>
	<script src="assets/js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	 <script src="js/popover.js"></script>
	 
	
  </body>
</html>
