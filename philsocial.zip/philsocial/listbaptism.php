<?php 
require_once("includes/initialize.php");
include("header.php");
?>
<div class="container">
<div class="row">
    <div class="col-md-12">
		<div class="well">
			<h2 class="text-center">Search Results</h2>
			<hr width="70%">
<table class="table table-striped">
	<thead>
		<tr>
			<th width="6%" align="left">Student Id</th>ge
			<th width="7%" align="left">Student Name</th>
			<th width="7%" align="left">Address</th>
			<th width="7%" align="center">Age</th>
			<th width="30%" align="left">Birth Place</th>
			<th width="17%" align="center">Sex</th>
			<th width="29%" align="center">Course</th>
			<th align="left">SY</th>	
							
		</tr>
	</thead>
	<tbody>
<?php
	
		global $mydb;
		$mydb->setQuery("SELECT * FROM stud_course");
	

	$cur = $mydb->loadResultList();
			foreach ($cur as $object){
			
				echo (@$odd == true) ? ' <tr class="odd_row" > ' : ' <tr class="even_row"> ';
				@$odd = !$odd;
					echo ' <td> ';
					echo '<a href="" class="app_listitem_key">'.$object->s_id.'</a>';
					echo ' <td> ';
					echo $object->s_name;
					echo ' <td> ';
					echo $object->s_address;
					echo ' <td> ';
					echo $object->s_age;
					echo ' <td> ';
					echo $object->s_bday;
					echo ' <td> ';
					echo $object->s_bplace;
					echo ' <td> ';
					echo $object->sex;
					echo ' <td> ';
					echo $object->course_name;
					echo ' <td> ';
					echo $object->sy;
			}
	

?>
			
			
			
			</tbody>
		</table>
		</div>
	</div>
		<!--/span--> 
		 <?php include('footer.php');?>
</div>
</div>

  