
<?php
require_once("includes/initialize.php");    

	$f_name   = $_POST['fName'];
	$l_name   = $_POST['lName'];
	$email    = $_POST['email'];
	$password = sha1($_POST['password']);
	$month	  = $_POST['month']; 
	$month    = $month + 1;
	$day	  = $_POST['day'];
	$yr	      = $_POST['yr'];
 	$bday     = $yr . '-' . $month . '-' .  $day;
	$gender   = $_POST['gender'];


		$member = new member();
		$member->fName 		= $f_name;
		$member->lName 		= $l_name;
		$member->email 		= $email;
		$member->pword 		= $password;
		$member->bday       = $bday;
		$member->gender		= $gender;
		$member->create();					
?>
    <script type="text/javascript">
		alert("New member added successfully.");
		window.location = "index.php"
	</script>
    